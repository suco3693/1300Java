/**
 * Makes the SoundToneGame run
 * 
 * @author Jeffrey LaMarhc 
 * @version 1.0 December 5th 2013
 */

import java.io.IOException;

public class PlaySoundToneGame
{
    public static void main(String [] args) throws IOException
    {
        SoundToneGame myGame = new SoundToneGame();
        
        myGame.runSoundToneGame();
    }
}
